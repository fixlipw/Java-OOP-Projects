import java.util.ArrayList;

public class Mercantil {
    ArrayList<Pessoa> lista_espera = new ArrayList<>();
    Pessoa[] caixas;

    Mercantil(int qtd) {
        this.caixas = new Pessoa[qtd];
    }

    /**
     * Adiciona uma pessoa na lista de espera
     * @param pessoa objeto pessoa a ser adicionado na lista
     */

    public void chegar(Pessoa pessoa){
        this.lista_espera.add(pessoa);
    }

    /**
     * Caixa recebe uma pessoa da lista de espera e a remove da mesma
     * @param indice índice do caixa a receber a pessoa. Caso a lista esteja vazia, imprime o erro.
     */

    public void chamar_no_caixa(int indice){
        try{
            this.caixas[indice] = this.lista_espera.get(0);
            this.lista_espera.remove(0);
        }
        catch (IndexOutOfBoundsException e){
            System.out.println("fail: lista vazia");
        }
    }

    /**
     * Caixa finaliza o atendimento e recebe null
     * @param indice índice do caixa a ter o atendimento finalizado
     */

    public void finalizar_atendimento(int indice){
        this.caixas[indice] = null;
    }

    @Override
    public String toString() {
        StringBuilder retorno = new StringBuilder("|");
        for(int i = 0; i < this.caixas.length; i++){
            if(this.caixas[i] != null){
                retorno.append(i).append(':').append(this.caixas[i]).append('|');
            }
            else{
                retorno.append(i).append(":-----|");
            }
        }
        retorno.append("\nEspera: ").append(this.lista_espera);
        return retorno.toString();
    }
}
