import java.util.*;

public class Solver {
    static Shell shell = new Shell();
    static Mercantil mercantil = new Mercantil(0);

    /**
     * Chama a função setFn para adicionar todas as funções a serem utilizadas<br />
     * Chama a função execute
     */

    public static void main(String[] args) {
        shell.setFn("init", () -> mercantil = new Mercantil(toInt(shell.par(1))));
        shell.setFn("call", () -> mercantil.chamar_no_caixa(toInt(shell.par(1))));
        shell.setFn("finish", () -> mercantil.finalizar_atendimento(toInt(shell.par(1))));
        shell.setFn("arrive", () -> mercantil.chegar(new Pessoa(shell.par(1))));
        shell.setFn("show", () -> System.out.println(mercantil));
        shell.execute();
    }

    /**
     * Converte a string recebida em inteiro
     * @param string string a ser convertida a inteiro
     * @return a string convertida em inteiro
     */
    static int toInt(String string){
        return Integer.parseInt(string);
    }
}

class Shell{
    private final Scanner sc = new Scanner(System.in);
    private final HashMap<String, Runnable> chain = new HashMap<>();
    private final ArrayList<String> ui = new ArrayList<>();

    public Shell(){
        Locale.setDefault(new Locale("en", "US"));
    }

    /**
     * Seta uma função, adicionando-a em um hashmap.
     * @param key   nome da função, dada por uma string
     * @param value execução a ser usada em relação ao nome da função
     */

    public void setFn(String key, Runnable value){
        chain.put(key, value);
    }

    /**
     * Retorna o elemento do ArrayList ‘ui’ dado pela posição especificada
     * @param index índice da string a ser retornada
     * @return a string na posição especificada
     */

    public String par(int index){
        return ui.get(index);
    }

    /**
     * No Loop:
     * <p>
     *     ui.clear() remove todos os itens da lista;<br />
     *     Declara, lê da entrada e armazena em 'line';<br />
     *     Imprime o comando recebido;<br />
     *     Armazena na lista de strings cada palavra de line separada por um espaço;<br />
     *     Se a primeira palavra de ui for "end", ele quebra o loop e encerra o programa;<br />
     *     Também, se o hashmap conter uma chave igual a primeira palavra de ui, pega o
     *     par e executa o valor da chave;<br />
     *     Senão, imprime que o comando não é válido;
     * </p>
     */

    public void execute(){
        while(true){
            ui.clear();
            String line = sc.nextLine();
            Collections.addAll(ui, line.split(" "));
            System.out.println("$"+line);

            if(par(0).equals("end")){
                break;
            }
            else if(chain.containsKey(par(0))){
                chain.get(par(0)).run();
            }
            else{
                System.out.println("fail: comando invalido");
            }
        }
    }
}

